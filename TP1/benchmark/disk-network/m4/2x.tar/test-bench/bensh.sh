#!/bin/bash

sudo apt-get update && Y
sudo apt-get upgrade && Y

sudo apt-get install build-essential && Y
sudo apt install speedtest-cli && Y

cmp=0
mkdir -p disk2 speed2
#______________________________________________________


for i in `seq 1 5`
do



echo  "bensh \"$cmp\" is running "

#3-network test
speedtest-cli >>speed2/speedtest"$cmp".txt

#4-Disk performance
#speed of a disk
sudo hdparm -Tt /dev/xvda >>disk2/disk"$cmp".txt

sleep 20s

cmp=$((cmp+1))

done
